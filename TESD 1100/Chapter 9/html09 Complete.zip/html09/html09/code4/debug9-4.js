﻿"use strict";

/*
   Debug Challenge 9-1
   Author: Jeffrey Jenson
   Date: 2026-01-21
*/

showImage();
setInterval(showImage, 5000);

function showImage() {
  let slideNumber = randNumber(1, 14);

  document.getElementById("slide").src = "slide" + slideNumber + ".jpg";

  document.getElementById("slidecaption").textContent = getCaption(slideNumber);
}

function randNumber(min, max) {
  return Math.floor(min + (max - min + 1) * Math.random());
}

function getCaption(slide) {
  let captions = new Array(15);

  captions[1] = "Assembling the International Space Station [1998]";
  captions[2] = "The Atlantis docks with the ISS [2001]";
  captions[3] = "The Atlantis approaches the ISS [2000]";
  captions[4] = "The Atlantis approaches the ISS [2000]";
  captions[5] = "International Space Station over Earth [2002]";
  captions[6] = "The International Space Station first expansion [2002]";
  captions[7] = "Hurricane Ivan from the ISS [2008]";
  captions[8] = "The Soyuz spacecraft approaches the ISS [2005]";
  captions[9] = "The International Space Station from above [2006]";
  captions[10] = "Maneuvering in space with the Canadarm2 [2006]";
  captions[11] = "The International Space Station second expansion [2006]";
  captions[12] = "The International Space Station third expansion [2007]";
  captions[13] = "The ISS over the Ionian Sea [2007]";
  captions[14] = "International Space Station fourth expansion [2009]";

  return captions[slide];
}
