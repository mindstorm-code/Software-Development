/*TESD 1800: Exercise 15 - Listeners (Implementation)
Jeffrey Jenson - Stu#6200029698
10/22/2025
(Move the Ball)
*/

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Exercise15_03 extends Application {
  @Override
  public void start(Stage primaryStage) {
    // Create BallPane (custom pane where the ball lives)
    BallPane ballPane = new BallPane();

    // Create control buttons
    Button btLeft = new Button("Left");
    Button btRight = new Button("Right");
    Button btUp = new Button("Up");
    Button btDown = new Button("Down");

    // Put buttons in an HBox
    HBox hBox = new HBox(10);
    hBox.setAlignment(Pos.CENTER);
    hBox.getChildren().addAll(btLeft, btRight, btUp, btDown);

    // Add listeners for buttons
    btLeft.setOnAction(e -> ballPane.moveLeft());
    btRight.setOnAction(e -> ballPane.moveRight());
    btUp.setOnAction(e -> ballPane.moveUp());
    btDown.setOnAction(e -> ballPane.moveDown());

    // Layout with BorderPane
    BorderPane borderPane = new BorderPane();
    borderPane.setCenter(ballPane);
    borderPane.setBottom(hBox);
    BorderPane.setAlignment(hBox, Pos.CENTER);

    // Create scene and stage
    Scene scene = new Scene(borderPane, 400, 300);
    primaryStage.setTitle("Exercise15_03");
    primaryStage.setScene(scene);
    primaryStage.show();
  }

  // Pane class for the moving ball
  class BallPane extends Pane {
    private Circle circle = new Circle(50, 50, 20); // (x, y, radius) - better starting position

    public BallPane() {
      circle.setStroke(Color.BLACK);
      circle.setFill(Color.WHITE);
      getChildren().add(circle);
    }

    // Move methods with boundary checks
    public void moveLeft() {
      if (circle.getCenterX() - circle.getRadius() > 0)
        circle.setCenterX(circle.getCenterX() - 10);
    }

    public void moveRight() {
      // Use a minimum width if getWidth() returns 0 (before layout)
      double paneWidth = getWidth() > 0 ? getWidth() : 400;
      if (circle.getCenterX() + circle.getRadius() < paneWidth)
        circle.setCenterX(circle.getCenterX() + 10);
    }

    public void moveUp() {
      if (circle.getCenterY() - circle.getRadius() > 0)
        circle.setCenterY(circle.getCenterY() - 10);
    }

    public void moveDown() {
      // Use a minimum height if getHeight() returns 0 (before layout)
      double paneHeight = getHeight() > 0 ? getHeight() : 250; // Account for button area
      if (circle.getCenterY() + circle.getRadius() < paneHeight)
        circle.setCenterY(circle.getCenterY() + 10);
    }
  }

  public static void main(String[] args) {
    launch(args);
  }
}
